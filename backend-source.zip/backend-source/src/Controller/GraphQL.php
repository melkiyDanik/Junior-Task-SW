<?php

namespace App\Controller;

use GraphQL\GraphQL as GraphQLBase;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\Type;
use GraphQL\Type\Schema;
use GraphQL\Type\SchemaConfig;
use PDO;
use Throwable;

class GraphQL {
    static public function handle() {
        try {
            $pdo = new PDO('mysql:host=ohayoproduction.dev;port=3306;dbname=junior', 'sasun3', '1488', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
            ]);

            // Типы для GraphQL остаются прежними
            $attributeItemType = new ObjectType([
                'name' => 'AttributeItem',
                'fields' => [
                    'id' => Type::string(),
                    'displayValue' => Type::string(),
                    'value' => Type::string(),
                ]
            ]);

            $attributeSetType = new ObjectType([
                'name' => 'AttributeSet',
                'fields' => [
                    'id' => Type::string(),
                    'name' => Type::string(),
                    'type' => Type::string(),
                    'items' => Type::listOf($attributeItemType),
                ]
            ]);

            $priceType = new ObjectType([
                'name' => 'Price',
                'fields' => [
                    'amount' => Type::float(),
                    'currency_label' => Type::string(),
                    'currency_symbol' => Type::string(),
                ]
            ]);

            $productType = new ObjectType([
                'name' => 'Product',
                'fields' => [
                    'id' => Type::string(),
                    'name' => Type::string(),
                    'inStock' => Type::boolean(),
                    'description' => Type::string(),
                    'category' => Type::string(),
                    'brand' => Type::string(),
                    'gallery' => Type::listOf(Type::string()),
                    'prices' => Type::listOf($priceType),
                    'attributes' => Type::listOf($attributeSetType),
                ]
            ]);

            $categoryType = new ObjectType([
                'name' => 'Category',
                'fields' => [ 'name' => Type::string() ]
            ]);

            // ИСПРАВЛЕННАЯ ФУНКЦИЯ СБОРКИ ДАННЫХ
            $resolveProductData = function($p, $pdo) {
                // 1. Галерея (Проверь таблицу: galleries или product_gallery)
                // На твоем скрине была таблица galleries
                $imgStmt = $pdo->prepare("SELECT image_url FROM galleries WHERE product_id = ?");
                $imgStmt->execute([$p['id']]);
                $gallery = $imgStmt->fetchAll(PDO::FETCH_COLUMN);

                // 2. Цены
                $priceStmt = $pdo->prepare("SELECT amount, currency_label, currency_symbol FROM prices WHERE product_id = ?");
                $priceStmt->execute([$p['id']]);
                $prices = $priceStmt->fetchAll();

                // 3. Атрибуты (СИНХРОНИЗАЦИЯ С ТВОЕЙ БД)
                $fullAttributes = [];
                try {
                    $attrStmt = $pdo->prepare("SELECT id, name, type FROM attributes WHERE product_id = ?");
                    $attrStmt->execute([$p['id']]);
                    $attributes = $attrStmt->fetchAll();

                    foreach ($attributes as $attr) {
                        // ВАЖНО: На твоем скриншоте колонка называется attribute_pk, а не attribute_id
                        $itemStmt = $pdo->prepare("SELECT item_id as id, display_value as displayValue, item_value as value FROM attribute_items WHERE attribute_pk = ?");
                        $itemStmt->execute([$attr['id']]);
                        $attr['items'] = $itemStmt->fetchAll();
                        $fullAttributes[] = $attr;
                    }
                } catch (Throwable $e) { $fullAttributes = []; }

                return [
                    'id' => $p['id'],
                    'name' => $p['name'],
                    'inStock' => (bool)$p['in_stock'],
                    'description' => $p['description'] ?? '',
                    'category' => $p['category'] ?? 'all',
                    'brand' => $p['brand'] ?? '',
                    'gallery' => !empty($gallery) ? $gallery : [$p['image_url'] ?? 'https://placehold.co/400'],
                    'prices' => $prices,
                    'attributes' => $fullAttributes
                ];
            };

            // Остальная часть (Query, Schema, Execution) остается без изменений
            $queryType = new ObjectType([
                'name' => 'Query',
                'fields' => [
                    'products' => [
                        'type' => Type::listOf($productType),
                        'resolve' => function() use ($pdo, $resolveProductData) {
                            $products = $pdo->query("SELECT * FROM products")->fetchAll();
                            return array_map(function($p) use ($pdo, $resolveProductData) {
                                return $resolveProductData($p, $pdo);
                            }, $products);
                        }
                    ],
                    'product' => [
                        'type' => $productType,
                        'args' => [ 'id' => ['type' => Type::nonNull(Type::string())] ],
                        'resolve' => function($root, $args) use ($pdo, $resolveProductData) {
                            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
                            $stmt->execute([$args['id']]);
                            $p = $stmt->fetch();
                            return $p ? $resolveProductData($p, $pdo) : null;
                        }
                    ],
                    'categories' => [
                        'type' => Type::listOf($categoryType),
                        'resolve' => fn() => $pdo->query("SELECT name FROM categories")->fetchAll()
                    ]
                ]
            ]);

            $schema = new Schema((new SchemaConfig())->setQuery($queryType));
            $input = json_decode(file_get_contents('php://input'), true);
            $query = $input['query'] ?? '';
            $variables = $input['variables'] ?? null;

            $result = GraphQLBase::executeQuery($schema, $query, null, null, $variables);
            $output = $result->toArray();

        } catch (Throwable $e) {
            $output = ['errors' => [['message' => $e->getMessage()]]];
        }

        header('Content-Type: application/json; charset=UTF-8');
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Content-Type");
        echo json_encode($output);
        exit;
    }
}
