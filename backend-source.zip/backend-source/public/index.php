<?php
// 1. Отключаем вывод ошибок прямо в поток (чтобы они не портили JSON)
ini_set('display_errors', 0); 

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

require_once __DIR__ . '/../vendor/autoload.php';

use App\Controller\GraphQL;

try {
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true);

    $controller = new GraphQL();
    $output = $controller->handle($input ?? []);

    // Убедись, что ПЕРЕД этим нет никаких echo
    header('Content-Type: application/json');
    echo json_encode($output);

} catch (\Throwable $e) {
    header('Content-Type: application/json');
    echo json_encode([
        'errors' => [['message' => $e->getMessage()]]
    ]);
}
